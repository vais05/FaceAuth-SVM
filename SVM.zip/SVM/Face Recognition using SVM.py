import os
from tkinter import *
import tkinter.font as font
import tkinter.simpledialog as simpledialog
from PIL import Image, ImageTk
from tkinter import messagebox as mbox

import cv2
import face_recognition
from sklearn import svm

registered_names = []
account_balances = {}

def train_svm():
    encodings = []
    names = []

    train_dir = os.listdir('train/')

    for person in train_dir:
        pix = os.listdir("train/" + person)

        for person_img in pix:
            face = face_recognition.load_image_file("train/" + person + "/" + person_img)
            face_bounding_boxes = face_recognition.face_locations(face)

            if len(face_bounding_boxes) == 1:
                face_enc = face_recognition.face_encodings(face)[0]
                encodings.append(face_enc)
                names.append(person)
            else:
                print(person + "/" + person_img + " was skipped and can't be used for training")

    clf = svm.SVC(gamma='scale')
    clf.fit(encodings, names)

    return clf

def test_svm(clf):
    test_image = face_recognition.load_image_file('test/test.jpg')
    face_locations = face_recognition.face_locations(test_image)
    num = len(face_locations)
    print("Number of faces detected: ", num)

    list_names = []
    print("Found:")
    for i in range(num):
        test_image_enc = face_recognition.face_encodings(test_image)[i]
        name = clf.predict([test_image_enc])
        print(name)
        list_names.append(*name)

    withdrawal_amount = simpledialog.askinteger(title="Online Banking", prompt="How much would you like to withdraw?:")
    update_balance(list_names[0], withdrawal_amount)
    display_transaction(list_names, withdrawal_amount)

def update_balance(name, withdrawal_amount):
    if name in account_balances:
        account_balances[name] -= withdrawal_amount

def test_img_capture():
    window.destroy()

    img_counter = 0
    if True:
        cam = cv2.VideoCapture(0)
        cv2.namedWindow("Face Recognition")
        while True:
            ret, frame = cam.read()
            if not ret:
                print("failed to grab frame")
                break
            cv2.imshow("Face Recognition", frame)

            k = cv2.waitKey(1)
            if k % 256 == 32:
                img_name = "test.jpg"
                cv2.imwrite(os.path.join('test', img_name), frame)
                print("{} written!".format(img_name))
                print("Closing now")
                img_counter += 1
                break

        cam.release()
        cv2.destroyAllWindows()

        trained_svm = train_svm()
        test_svm(trained_svm)

def register_img_capture():
    cam = cv2.VideoCapture(0)
    cv2.namedWindow("Face Registration")
    img_counter = 0

    file_name = simpledialog.askstring(title="Online Banking", prompt="Welcome! What's your Name?:")
    window = Tk()
    window.withdraw()

    if file_name in registered_names:
        mbox.showinfo("Information", f"Welcome back, {file_name}!")
        return

    os.mkdir("train/" + file_name)

    while True:
        ret, frame = cam.read()
        if not ret:
            print("failed to grab frame")
            break
        cv2.imshow("Face Registration", frame)

        k = cv2.waitKey(1)
        if k % 256 == 27:
            print("Escape hit, closing...")
            break
        elif k % 256 == 32:
            img_name = file_name+"_{}.jpg".format(img_counter)
            cv2.imwrite(os.path.join("train/"+file_name, img_name), frame)
            print("{} written!".format(img_name))
            img_counter += 1

    cam.release()
    cv2.destroyAllWindows()
    mbox.showinfo("Information", f"Welcome, {file_name}! Your account has been registered successfully.")

    registered_names.append(file_name)
    account_balances[file_name] = 1000  
    
    amount = simpledialog.askinteger(title="Online Banking", prompt="How much amount do you have in your bank?:")
    account_balances[file_name] = amount
    display_transaction([file_name], amount)

def display_transaction(names, amount): 
    for name in names:
        updated_balance = account_balances.get(name, 0)
        mbox.showinfo("Transaction Details", f"Transaction successful! {name}, you withdrew ${amount}\nUpdated Balance: ${updated_balance}")

def display_name(list_name):
    window = Tk()
    label = Label(window, text="Faces Recognized")
    listbox = Listbox(window, width=50)
    label.pack()
    listbox.pack(fill=BOTH, expand=1)
    for row in list_name:
        listbox.insert(END, row)
    window.after(5000, window.destroy)
    window.mainloop()

window = Tk()
window.config(width=300, height=300, padx=20, pady=50)
label = Label(
    window, text='WELCOME TO ONLINE BANKING. SELECT AN OPTION BELOW:\n', font=font.Font(size=16))
label.pack()
button = Button(window, text="Register", command=register_img_capture, width=20, bg="red", fg="white", pady=10)
button['font'] = font.Font(size=16)
button.pack()
label = Label(window, text='\n')
label.pack()
button = Button(window, text="Login", command=test_img_capture, width=20, bg="#0052cc", fg="white", pady=10)
button['font'] = font.Font(size=16)
button.pack()
label = Label(window, text="\nInstructions\nIf you haven't registered, go to Register. If you have registered, go to Login.\n1).In Register Mode, enter your name and then press SPACEBAR to capture images. Hit ESC when done.\n2).In Login Mode, press SPACEBAR to capture image and display detected face", font=font.Font(size=14))
label.pack()
window.mainloop()
